winusbdotnet
============

WinUSB based managed USB communications library

Yes, another one. Why? The following reasons:
* I want to support system level actions like loading winusb on arbitrary devices in a built-in fashion
* I'm very peculiar about how I want my interfaces to look
* Because I can, I guess.
